#!/usr/bin/env python3
import random
import argparse

DEFAULT_WORDS = [
    "apple",
    "banana",
    "cherry",
    "delta",
    "echo",
    "foxtrot",
    "golf",
    "hotel",
    "india",
    "juliet",
    "kilo",
    "lemur",
    "mango",
    "nectar",
    "omega",
    "panda",
    "quartz",
    "rocket",
    "sierra",
    "tango",
    "umbrella",
    "violet",
    "whiskey",
    "xenon",
    "yellow",
    "zebra",
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate random words from a built-in or custom list."
    )
    parser.add_argument(
        "-n",
        "--number",
        type=int,
        default=1,
        help="Number of random words to generate (default: 1).",
    )
    parser.add_argument(
        "-u",
        "--unique",
        action="store_true",
        help="Return unique words when possible.",
    )
    parser.add_argument(
        "-f",
        "--file",
        type=str,
        default=None,
        help="Load words from a custom file, one word per line.",
    )
    return parser.parse_args()


def load_words_from_file(path):
    try:
        with open(path, "r", encoding="utf-8") as file:
            words = [line.strip() for line in file if line.strip()]
        if not words:
            raise ValueError("Word file is empty.")
        return words
    except FileNotFoundError:
        raise SystemExit(f"Error: File not found: {path}")
    except PermissionError:
        raise SystemExit(f"Error: Permission denied: {path}")
    except ValueError as error:
        raise SystemExit(f"Error: {error}")


def main():
    args = parse_args()
    words = DEFAULT_WORDS if args.file is None else load_words_from_file(args.file)

    if args.number < 1:
        raise SystemExit("Error: Number of words must be at least 1.")

    if args.unique and args.number > len(words):
        raise SystemExit(
            f"Error: Cannot generate {args.number} unique words from a list of {len(words)} words."
        )

    if args.unique:
        selection = random.sample(words, args.number)
    else:
        selection = [random.choice(words) for _ in range(args.number)]

    print("\n".join(selection))


if __name__ == "__main__":
    main()
